The cleaned csv files are ttrain.csv and test.csv

Run the neural.r file and copy the pred3 table in output.txt

run count.py with output.txt as input
python3 count.py < output.txt


--------------------------------------------------------------------------------
output.txt currently has my latest run of the algorithm.
running count.py with it gives an output of:

Death: 192 | Survive: 139
